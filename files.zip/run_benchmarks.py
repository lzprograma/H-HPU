#!/usr/bin/env python3
"""run_benchmarks.py -- parametriza a rede, injeta a carga relacional e consolida metricas.

Uso:  python3 run_benchmarks.py --N 1000 --rate 0.10 --cycles 2000 --seeds 3 --sweep
Saidas: results.json, results.csv, topology.csv, sweep.csv (se --sweep)
"""
import argparse
import csv
import json
import time

import numpy as np

from hhpu_sim import Simulation, analytic_metrics, build_hex, build_mesh2d

CONFIGS = {
    # nome: (topologia, harc, hmem)
    "mesh2d_baseline": ("mesh", False, False),
    "hex6_open_loop": ("hex", False, True),
    "mesh2d_harc": ("mesh", True, True),   # ablacao: HARC sem topologia hexagonal
    "hex6_harc": ("hex", True, True),      # H-HPU completa (modelo)
}


def topology_table(sizes):
    rows = []
    for n in sizes:
        m, h = build_mesh2d(n), build_hex(n)
        for t in (m, h):
            a = analytic_metrics(t.N)
            is_h = t.name.startswith("hex")
            rows.append(dict(
                topology=t.name, N=t.N, avg_degree=round(t.avg_degree, 3),
                diameter_measured=t.diameter(), diameter_formula=round(a["D_hex" if is_h else "D_grid"], 3),
                bisection_cut_measured=t.bisection_width(),
                bisection_formula=round(a["B_hex" if is_h else "B_grid"], 3),
                avg_path_length=round(t.avg_path_length(), 3)))
    return rows


def run_config(name, N, rate, cycles, warmup, window, seeds):
    kind, harc, hmem = CONFIGS[name]
    runs = []
    for s in range(seeds):
        topo = build_mesh2d(N) if kind == "mesh" else build_hex(N)
        runs.append(Simulation(topo, rate=rate, cycles=cycles, warmup=warmup, window=window,
                               harc=harc, hmem=hmem, seed=s).run())
    agg = {"config": name, "seeds": seeds, "N": runs[0]["N"], "topology": runs[0]["topology"], "rate": rate}
    for k, v in runs[0].items():
        if isinstance(v, (int, float)) and k not in ("N",):
            xs = [r[k] for r in runs]
            agg[k] = float(np.mean(xs))
            agg[k + "_sd"] = float(np.std(xs))
    return agg


def write_csv(path, rows):
    keys = list(rows[0].keys())
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=1000)
    ap.add_argument("--rate", type=float, default=0.10, help="requisicoes/no/ciclo")
    ap.add_argument("--cycles", type=int, default=2000)
    ap.add_argument("--warmup", type=int, default=600)
    ap.add_argument("--window", type=int, default=100)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--sweep", action="store_true", help="varre taxa de injecao")
    ap.add_argument("--out", default=".")
    a = ap.parse_args()

    t0 = time.time()
    topo_rows = topology_table([100, 400, a.N, 3000])
    write_csv(f"{a.out}/topology.csv", topo_rows)

    results = [run_config(n, a.N, a.rate, a.cycles, a.warmup, a.window, a.seeds) for n in CONFIGS]
    ref = next(r for r in results if r["config"] == "hex6_open_loop")["U_M_steady"]
    for r in results:
        r["U_M_reduction_vs_open_loop_pct"] = 100.0 * (ref - r["U_M_steady"]) / ref
    with open(f"{a.out}/results.json", "w") as f:
        json.dump(dict(params=vars(a), topology=topo_rows, results=results), f, indent=2)
    write_csv(f"{a.out}/results.csv", results)

    if a.sweep:
        sw = []
        for rate in (0.05, 0.10, 0.20, 0.30):
            for n in ("mesh2d_baseline", "hex6_harc"):
                sw.append(run_config(n, a.N, rate, a.cycles, a.warmup, a.window, 1))
        write_csv(f"{a.out}/sweep.csv", [{k: r[k] for k in (
            "config", "rate", "avg_hops", "avg_latency_cycles",
            "throughput_flits_per_cycle", "reject_ratio", "U_M_steady")} for r in sw])

    print(f"{'config':18s} {'N':>5s} {'hops':>6s} {'lat(cyc)':>9s} {'thr(f/c)':>9s} {'U_M':>7s} {'dU_M%':>7s} {'inv/wr':>7s}")
    for r in results:
        print(f"{r['config']:18s} {r['N']:5d} {r['avg_hops']:6.2f} {r['avg_latency_cycles']:9.2f} "
              f"{r['throughput_flits_per_cycle']:9.1f} {r['U_M_steady']:7.3f} "
              f"{r['U_M_reduction_vs_open_loop_pct']:7.2f} {r['inv_msgs_per_write']:7.2f}")
    print(f"tempo total: {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
