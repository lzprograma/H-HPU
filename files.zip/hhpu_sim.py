"""
hhpu_sim.py -- Simulador comportamental de alto nivel: H-HPU (H6-NoC + H-MESI + HARC) vs. 2D-Mesh.

Modelo (resumo):
  * Topologias: Mesh2D (grau 4) e H6 (regiao hexagonal da malha triangular, grau 6; N = 1 + 3R(R+1)).
  * NoC: cycle-driven, 1 flit/ciclo/enlace direcionado, filas ilimitadas, roteamento por caminho
    minimo. 'static' = primeiro candidato minimo (na grade equivale a XY); 'adaptive' = escolha por
    ocupacao de fila, com peso lambda_q ajustado pelo HARC.
  * Carga: traces estocasticos hierarquicos (blocos de tamanho 2^l sobre ordenacao RCB), com
    N*ceil(log2 N) requisicoes por "epoca" -> trafego O(N log N). Nao ha GEMM.
  * H-MESI: diretorio com mascara local de sharers (grau: 4/6 bits) + resumo por cluster (SC);
    invalida apenas sharers reais; nunca faz broadcast global.
  * HARC: controlador de malha fechada (integrador com safety filter) que regula U_M -> alvo 0.93.

Limitacoes assumidas (ver README/relatorio): sem modelagem de VCs/turn-model (filas ilimitadas),
sem PHY/buffers finitos, sem latencia de memoria; U_M e calibrado exogenamente (ver Simulation).
"""
from __future__ import annotations

import math
from collections import deque

import numpy as np

DIRS_HEX = [(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1)]  # coordenadas axiais (Sec. 3.4)


# --------------------------------------------------------------------------------------
# Formulas analiticas de referencia (HexaMesh, Sec. 3.3 do whitepaper)
# --------------------------------------------------------------------------------------
def analytic_metrics(N: float) -> dict:
    return {
        "D_grid": 2 * math.sqrt(N) - 2,
        "B_grid": math.sqrt(N),
        "D_hex": (1 / 3) * math.sqrt(12 * N - 3) - 0.5,
        "B_hex": (2 / 3) * math.sqrt(12 * N - 3),
    }


# --------------------------------------------------------------------------------------
# Grafos de rede
# --------------------------------------------------------------------------------------
class Topology:
    def __init__(self, name: str, coords: list, adj: list):
        self.name, self.coords, self.adj = name, coords, adj
        self.N = len(adj)
        self._D = None

    @property
    def avg_degree(self) -> float:
        return sum(len(a) for a in self.adj) / self.N

    @property
    def n_edges(self) -> int:
        return sum(len(a) for a in self.adj) // 2

    def bfs(self, s: int) -> list:
        d = [-1] * self.N
        d[s] = 0
        dq = deque([s])
        while dq:
            u = dq.popleft()
            for v in self.adj[u]:
                if d[v] < 0:
                    d[v] = d[u] + 1
                    dq.append(v)
        return d

    def dist_table(self) -> list:
        if self._D is None:
            self._D = [self.bfs(s) for s in range(self.N)]
        return self._D

    def diameter(self) -> int:
        return max(max(r) for r in self.dist_table())

    def avg_path_length(self) -> float:
        D = self.dist_table()
        return sum(map(sum, D)) / (self.N * (self.N - 1))

    def bisection_width(self) -> int:
        """Corte geometrico balanceado (N/2 | N/2); minimo sobre 6 direcoes. Limite superior da bisseccao."""
        best = None
        for k in range(6):
            a = math.pi * k / 6
            cx, cy = math.cos(a), math.sin(a)
            order = sorted(range(self.N), key=lambda i: self.coords[i][0] * cx + self.coords[i][1] * cy)
            left = set(order[: self.N // 2])
            cut = sum(1 for u in left for v in self.adj[u] if v not in left)
            best = cut if best is None else min(best, cut)
        return best


def build_mesh2d(N: int) -> Topology:
    k = max(2, round(math.sqrt(N)))
    idx = lambda x, y: y * k + x
    coords = [(x, y) for y in range(k) for x in range(k)]
    adj = [[] for _ in range(k * k)]
    for y in range(k):
        for x in range(k):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):  # ordem x-primeiro => estatico == XY
                xx, yy = x + dx, y + dy
                if 0 <= xx < k and 0 <= yy < k:
                    adj[idx(x, y)].append(idx(xx, yy))
    return Topology(f"mesh2d_{k}x{k}", coords, adj)


def build_hex(N: int) -> Topology:
    R = min(range(1, 200), key=lambda r: abs(1 + 3 * r * (r + 1) - N))
    cells = [(q, r) for q in range(-R, R + 1) for r in range(-R, R + 1) if abs(q + r) <= R]
    index = {c: i for i, c in enumerate(cells)}
    coords = [(q + r / 2.0, r * math.sqrt(3) / 2.0) for q, r in cells]
    adj = [[] for _ in cells]
    for (q, r), i in index.items():
        for dq, dr in DIRS_HEX:
            j = index.get((q + dq, r + dr))
            if j is not None:
                adj[i].append(j)
    return Topology(f"hex6_R{R}", coords, adj)


def rcb_placement(topo: Topology) -> list:
    """Recursive Coordinate Bisection. Retorna phys[logical_id] -> no fisico (preserva localidade)."""
    out = []

    def rec(ids):
        if len(ids) <= 1:
            out.extend(ids)
            return
        xs = [topo.coords[i][0] for i in ids]
        ys = [topo.coords[i][1] for i in ids]
        ax = 0 if (max(xs) - min(xs)) >= (max(ys) - min(ys)) else 1
        ids = sorted(ids, key=lambda i: (topo.coords[i][ax], topo.coords[i][1 - ax]))
        m = len(ids) // 2
        rec(ids[:m])
        rec(ids[m:])

    rec(list(range(topo.N)))
    return out


# --------------------------------------------------------------------------------------
# Gerador de traces relacionais/hierarquicos  (trafego O(N log N) por epoca)
# --------------------------------------------------------------------------------------
class RelationalTraceGenerator:
    """Cada requisicao: origem uniforme; nivel l ~ U{1..L}, L=ceil(log2 N); destino uniforme no
    bloco ancestral de 2^l entidades (distancia em arvore ~ log-uniforme, proxy de acesso a
    vizinhancas hierarquicas/hiperbolicas). Linhas por home: K (compartilhamento forcado)."""

    def __init__(self, N, rate, cycles, write_frac=0.2, lines_per_home=4, level_bias=0.0, seed=0):
        self.N, self.L = N, max(1, math.ceil(math.log2(N)))
        rng = np.random.default_rng(seed)
        counts = rng.poisson(rate * N, cycles)
        E = int(counts.sum())
        src = rng.integers(0, N, E)
        w = np.exp(-level_bias * np.arange(1, self.L + 1))
        lvl = rng.choice(np.arange(1, self.L + 1), size=E, p=w / w.sum())
        base = (src >> lvl) << lvl
        dst = base + (rng.random(E) * (1 << lvl)).astype(np.int64)
        dst = np.where(dst >= N, dst % N, dst)
        dst = np.where(dst == src, np.where(src ^ 1 < N, src ^ 1, src - 1), dst)
        self.src, self.dst = src, dst
        self.line = rng.integers(0, lines_per_home, E)
        self.is_write = rng.random(E) < write_frac
        self.offsets = np.concatenate([[0], np.cumsum(counts)])
        self.epoch_ops = N * self.L  # requisicoes por epoca: Theta(N log N)

    def events(self, cycle):
        a, b = self.offsets[cycle], self.offsets[cycle + 1]
        for i in range(a, b):
            yield int(self.src[i]), int(self.dst[i]), int(self.line[i]), bool(self.is_write[i])


# --------------------------------------------------------------------------------------
# Diretorio H-MESI
# --------------------------------------------------------------------------------------
class _Line:
    __slots__ = ("state", "owner", "local_mask", "sc", "version")

    def __init__(self):
        self.state, self.owner, self.version = "I", None, 0
        self.local_mask = set()  # sharers entre vizinhos imediatos do home (<= grau bits)
        self.sc = {}             # cluster_id -> {sharers exatos} (resumo por cluster)


class HMESIDirectory:
    def __init__(self, topo: Topology, phys: list, cluster_size: int = 16):
        self.topo, self.cluster_size = topo, cluster_size
        self.logical = {p: l for l, p in enumerate(phys)}
        self.lines = {}
        self.stats = dict(reads=0, writes=0, inv_msgs=0, inv_local=0, inv_cluster=0,
                          broadcast_equiv=0, max_local_mask=0, violations=0)

    def cluster(self, node):
        return self.logical[node] // self.cluster_size

    def _line(self, home, line):
        return self.lines.setdefault((home, line), _Line())

    def read(self, home, line, req):
        e = self._line(home, line)
        self.stats["reads"] += 1
        if e.state == "M" and e.owner is not None and e.owner != req:
            self._add(e, home, e.owner)  # downgrade M->S: antigo owner vira sharer
        e.state = "S" if (e.local_mask or e.sc or req != home) else "E"
        if req != home:
            self._add(e, home, req)
        self.stats["max_local_mask"] = max(self.stats["max_local_mask"], len(e.local_mask))

    def _add(self, e, home, node):
        if node in self.topo.adj[home]:
            e.local_mask.add(node)
        else:
            e.sc.setdefault(self.cluster(node), set()).add(node)

    def write(self, home, line, req):
        """Retorna lista de destinos de invalidacao (mensagens na NoC). Sem broadcast."""
        e = self._line(home, line)
        self.stats["writes"] += 1
        targets = [n for n in e.local_mask if n != req]
        n_local = len(targets)
        n_cluster = 0
        for cid, members in e.sc.items():
            live = [m for m in members if m != req]
            if live:
                targets.append(min(live))  # representante do cluster (fan-out intra-cluster nao entra na NoC)
                n_cluster += 1
        self.stats["inv_msgs"] += len(targets)
        self.stats["inv_local"] += n_local
        self.stats["inv_cluster"] += n_cluster
        self.stats["broadcast_equiv"] += self.topo.N - 1
        old_version = e.version
        e.local_mask.clear()
        e.sc.clear()
        e.owner, e.state, e.version = req, "M", old_version + 1
        if e.version != old_version + 1 or (e.local_mask or e.sc):
            self.stats["violations"] += 1  # invariante: versao monotonica + zero sharers apos escrita
        return targets


# --------------------------------------------------------------------------------------
# NoC cycle-driven
# --------------------------------------------------------------------------------------
class Flit:
    __slots__ = ("src", "dst", "birth", "hops", "kind", "home", "line", "req", "write")

    def __init__(self, src, dst, birth, kind, home=None, line=0, req=None, write=False):
        self.src, self.dst, self.birth, self.hops, self.kind = src, dst, birth, 0, kind
        self.home, self.line, self.req, self.write = home, line, req, write


class NoC:
    BIAS = 4.0  # penalidade (em flits) para candidatos nao-preferidos quando lambda_q = 0

    def __init__(self, topo: Topology, adaptive: bool, on_deliver):
        self.topo, self.adaptive, self.on_deliver = topo, adaptive, on_deliver
        self.D = topo.dist_table()
        self.q = [{v: deque() for v in topo.adj[u]} for u in range(topo.N)]
        self.active = set()
        self.lambda_q = 0.0
        self.in_flight = 0

    def _next_hop(self, u, dst):
        du, Dd = self.D[dst][u], self.D[dst]
        cands = [v for v in self.topo.adj[u] if Dd[v] == du - 1]
        if len(cands) == 1 or not self.adaptive or self.lambda_q <= 0:
            return cands[0]
        pen = (1.0 - self.lambda_q) * self.BIAS
        return min(((len(self.q[u][v]) + pen * r, v) for r, v in enumerate(cands)))[1]

    def enqueue(self, u, f, cycle):
        if u == f.dst:
            self.in_flight -= 1
            self.on_deliver(f, cycle)
            return
        v = self._next_hop(u, f.dst)
        self.q[u][v].append(f)
        self.active.add((u, v))

    def inject(self, f, cycle):
        self.in_flight += 1
        self.enqueue(f.src, f, cycle)

    def step(self, cycle):
        moves = []
        for (u, v) in list(self.active):
            qd = self.q[u][v]
            moves.append((v, qd.popleft()))
            if not qd:
                self.active.discard((u, v))
        for v, f in moves:
            f.hops += 1
            self.enqueue(v, f, cycle)

    def mean_queue(self):
        if not self.active:
            return 0.0
        return sum(len(self.q[u][v]) for u, v in self.active) / len(self.active)


# --------------------------------------------------------------------------------------
# HARC: controlador adaptativo de malha fechada
# --------------------------------------------------------------------------------------
class HARC:
    """s = [q, m, b] -> a = [lambda_q (route), r (prefetch/placement/compressao => reducao de trafego de memoria)].
    Atuador de memoria: integrador sobre erro (U_med - alvo), com safety filter (clamp, rate-limit, watchdog)."""

    def __init__(self, target_um=0.93, ki=0.6, a_max=0.25, max_step=0.05, q_ref=2.0, ema=0.5):
        self.target, self.ki, self.a_max, self.max_step = target_um, ki, a_max, max_step
        self.q_ref, self.ema = q_ref, ema
        self.a, self.lambda_q, self.u_f = 0.0, 0.0, None
        self.log = []

    def safety_filter(self, a_prop, lam_prop):
        if not (math.isfinite(a_prop) and math.isfinite(lam_prop)):  # watchdog -> fallback deterministico
            return 0.0, 0.0
        a = min(self.a_max, max(0.0, a_prop))
        a = min(self.a + self.max_step, max(self.a - self.max_step, a))
        return a, min(1.0, max(0.0, lam_prop))

    def step(self, window, q_mean, u_meas):
        self.u_f = u_meas if self.u_f is None else self.ema * u_meas + (1 - self.ema) * self.u_f
        a_prop = self.a + self.ki * (self.u_f - self.target)
        lam_prop = q_mean / self.q_ref
        self.a, self.lambda_q = self.safety_filter(a_prop, lam_prop)
        self.log.append(dict(window=window, q=q_mean, U=u_meas, U_filt=self.u_f,
                             a=self.a, lambda_q=self.lambda_q))
        return self.a, self.lambda_q


# --------------------------------------------------------------------------------------
# Simulacao integrada
# --------------------------------------------------------------------------------------
class Simulation:
    U_BASE = 0.957          # calibracao exogena (whitepaper Sec. 6.5/8.5): U_M sem overhead
    HMEM_OVERHEAD = 0.08    # overhead de metadados/H-MEM (Sec. 6.5)

    def __init__(self, topo, rate=0.10, cycles=2000, warmup=500, window=100, harc=False, hmem=True,
                 adaptive=None, write_frac=0.2, seed=0, inflight_cap_per_node=8):
        self.topo, self.rate, self.cycles, self.warmup, self.window = topo, rate, cycles, warmup, window
        self.hmem, self.harc = hmem, HARC() if harc else None
        self.phys = rcb_placement(topo)
        self.trace = RelationalTraceGenerator(topo.N, rate, cycles, write_frac, seed=seed)
        self.dir = HMESIDirectory(topo, self.phys)
        adaptive = bool(harc) if adaptive is None else adaptive
        self.noc = NoC(topo, adaptive, self._deliver)
        self.cap = inflight_cap_per_node * topo.N
        # capacidade de memoria por no (req/ciclo): rate/U_BASE  => U_raw = 0.957 em carga nominal
        self.C_M = rate / self.U_BASE
        self.mem_arrivals = 0
        self.rejected = self.offered = 0
        self.delivered = self.hops_sum = self.lat_sum = 0
        self.req_delivered = self.req_hops_sum = 0
        self.um_windows, self.q_windows = [], []

    # ---- protocolo ----
    def _deliver(self, f, cycle):
        if f.birth >= self.warmup:
            self.delivered += 1
            self.hops_sum += f.hops
            self.lat_sum += cycle - f.birth
        if f.kind == "REQ":
            self.mem_arrivals += 1
            if f.birth >= self.warmup:
                self.req_delivered += 1
                self.req_hops_sum += f.hops
            home, req = f.dst, f.src
            if f.write:
                for t in self.dir.write(home, f.line, req):
                    self.noc.inject(Flit(home, t, cycle, "INV", home=home), cycle)
            else:
                self.dir.read(home, f.line, req)
            self.noc.inject(Flit(home, req, cycle, "RESP"), cycle)
        elif f.kind == "INV":
            self.noc.inject(Flit(f.dst, f.home, cycle, "ACK"), cycle)

    # ---- laco principal ----
    def run(self):
        N, ph = self.topo.N, self.phys
        for cyc in range(self.cycles):
            for s, d, ln, wr in self.trace.events(cyc):
                self.offered += 1
                if self.noc.in_flight > self.cap:
                    self.rejected += 1
                    continue
                self.noc.inject(Flit(ph[s], ph[d], cyc, "REQ", line=ln, write=wr), cyc)
            self.noc.step(cyc)
            if (cyc + 1) % self.window == 0:
                self._end_window(cyc)
        return self.summary()

    def _end_window(self, cyc):
        lam_obs = self.mem_arrivals / (self.topo.N * self.window)
        self.mem_arrivals = 0
        a = self.harc.a if self.harc else 0.0
        ovh = (1 + self.HMEM_OVERHEAD) if self.hmem else 1.0
        u = lam_obs * ovh * (1 - a) / self.C_M
        qm = self.noc.mean_queue()
        self.um_windows.append(u)
        self.q_windows.append(qm)
        if self.harc:
            _, lam = self.harc.step(len(self.um_windows), qm, u)
            self.noc.lambda_q = lam

    def summary(self):
        half = max(1, len(self.um_windows) // 2)
        meas = self.cycles - self.warmup
        st = self.dir.stats
        wr = max(1, st["writes"])
        return dict(
            N=self.topo.N, topology=self.topo.name,
            avg_hops=self.hops_sum / max(1, self.delivered),
            avg_req_hops=self.req_hops_sum / max(1, self.req_delivered),
            avg_latency_cycles=self.lat_sum / max(1, self.delivered),
            throughput_flits_per_cycle=self.delivered / meas,
            throughput_per_node=self.delivered / meas / self.topo.N,
            reject_ratio=self.rejected / max(1, self.offered),
            U_M_steady=float(np.mean(self.um_windows[-half:])),
            U_M_std=float(np.std(self.um_windows[-half:])),
            mean_queue=float(np.mean(self.q_windows[-half:])),
            inv_msgs_per_write=st["inv_msgs"] / wr,
            broadcast_msgs_per_write=st["broadcast_equiv"] / wr,
            max_local_mask_bits=st["max_local_mask"],
            coherence_violations=st["violations"],
            harc_a_final=self.harc.a if self.harc else 0.0,
        )
